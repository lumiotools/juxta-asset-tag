#ifndef BATTERY_INDICATOR_LED_H
#define BATTERY_INDICATOR_LED_H

#include <Adafruit_NeoPixel.h>
#include "battery_monitor.h"

class BatteryIndicatorLED {
private:
  static const int BATTERY_LED_PIN = 38;
  static const int NUM_PIXELS = 1;
  Adafruit_NeoPixel led;
  bool enabled = true;  // Track if LED is enabled
  
public:
  BatteryIndicatorLED() : led(NUM_PIXELS, BATTERY_LED_PIN, NEO_GRB + NEO_KHZ800) {
    // Don't initialize in constructor - causes boot crash
  }

  void begin() {
    led.begin();  // Initialize GPIO here, after boot
    led.setBrightness(200);
    led.show();
    enabled = true;
  }

  void updateBatteryLED() {
    if (!enabled) return;  // Don't update if disabled
    uint32_t color = BatteryMonitor::getBatteryColor();
    uint8_t r = (color >> 16) & 0xFF;
    uint8_t g = (color >> 8) & 0xFF;
    uint8_t b = color & 0xFF;
    led.setPixelColor(0, led.Color(r, g, b));
    led.show();
  }

  void setColor(uint8_t red, uint8_t green, uint8_t blue) {
    if (!enabled) return;  // Don't set color if disabled
    led.setPixelColor(0, led.Color(red, green, blue));
    led.show();
  }

  void enable() {
    enabled = true;
    updateBatteryLED();  // Restore battery LED color
  }

  void disable() {
    enabled = false;
    led.setPixelColor(0, led.Color(0, 0, 0));  // Turn off LED
    led.show();
  }

  bool isEnabled() {
    return enabled;
  }

  void doubleBlink() {
    if (!enabled) return;  // Don't blink if disabled
    for (int i = 0; i < 2; i++) {
      setColor(255, 0, 0);
      delay(100);
      setColor(0, 0, 0);
      delay(100);
    }
  }

  void dimTo20Percent() {
    // Dim to 20% of original brightness (200 * 0.2 = 40)
    // Note: Brightness is auto-restored on wake from deep sleep via begin()
    led.setBrightness(40);
    if (enabled) {
      updateBatteryLED();  // Update with dimmed brightness
    }
  }
};

#endif
